# coding:utf-8
import gensim
import shutil
import datetime as dt
from sys import platform

# 计算行数，就是单词数
def getFileLineNums(filename):
    f = open(filename, 'r')
    count = 0
    for line in f:
        count += 1
    return count


# Linux或者Windows下打开词向量文件，在开始增加一行
def prepend_line(infile, outfile, line):
    with open(infile, 'r') as old:
        with open(outfile, 'w') as new:
            new.write(str(line) + "\n")
            shutil.copyfileobj(old, new)


def prepend_slow(infile, outfile, line):
    with open(infile, 'r') as fin:
        with open(outfile, 'w') as fout:
            fout.write(line + "\n")
            for line in fin:
                fout.write(line)


def load(filename):
    num_lines = getFileLineNums(filename)
    gensim_file =  'glove_model.txt'
    gensim_first_line = "{} {}".format(num_lines, 300)
    # Prepends the line.
    if platform == "linux" or platform == "linux2":
        prepend_line(filename, gensim_file, gensim_first_line)
    else:
        prepend_slow(filename, gensim_file, gensim_first_line)

    model = gensim.models.KeyedVectors.load_word2vec_format(gensim_file, binary=False)
    for key in model.similar_by_word('男人', topn=10):
        print(key)
if __name__ == '__main__':
    vectorfile='vectors.txt'
    
    model = gensim.models.KeyedVectors.load_word2vec_format('glove_model.txt', binary=False)
    print('运动:')
    for key in model.similar_by_word(u'运动', topn=10):
        print(key[0].encode('utf8')+', '+str(key[1]))
    
    
    
