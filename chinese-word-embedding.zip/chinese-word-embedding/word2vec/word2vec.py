# coding:utf-8
import multiprocessing
import datetime as dt
from gensim.models import Word2Vec
from gensim.models.word2vec import LineSentence

if __name__ == "__main__":
    print('主程序开始执行...')

    input_file_name = 'wiki.txt'
    model_file_name = 'wiki.model'

    print('转换过程开始...')
    now_time = dt.datetime.now()
    print(now_time)
    model1 = Word2Vec(LineSentence(input_file_name),
                     size=300,  # 词向量长度为400
                     window=8,
                     min_count=5,
                     workers=multiprocessing.cpu_count())
    print('转换过程结束！')
    now_time = dt.datetime.now()
    print(now_time)

    print('开始保存模型...')
    model1.save(model_file_name)
    print('模型保存结束！')

    print('主程序执行结束！')
