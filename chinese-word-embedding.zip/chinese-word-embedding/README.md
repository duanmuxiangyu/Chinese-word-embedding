﻿#中文词向量
pre-processing:预处理包括分词、繁简转换等
glove：glove训练
word2vec：word2vec训练
fasttext：fasttext训练
Chinese-Word-Vectors-master: 中文词向量评估
word-embeddings-benchmarks：英文词向量评估
