# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 19:10:25 2019

@author: rainzy
"""



import multiprocessing
import datetime as dt
from gensim.models import FastText

from gensim.models.word2vec import LineSentence



if __name__ == "__main__":

    print('主程序开始执行...')



    input_file_name = 'wiki.txt'

    model_file_name = 'wiki.model.fasttext'



    print('转换过程开始...')
    now_time = dt.datetime.now()
    print(now_time)

    model = FastText(LineSentence(input_file_name),

                     size=300,  # 词向量长度为100

                     window=8,

                     min_count=8,

                     workers=multiprocessing.cpu_count())

    print('转换过程结束！')
    now_time = dt.datetime.now()
    print(now_time)



    print('开始保存模型...')

    model.save(model_file_name)

    print('模型保存结束！')



    print('主程序执行结束！')
